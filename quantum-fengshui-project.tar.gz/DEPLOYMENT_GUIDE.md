# 部署指南 - 如何避免快取問題

## ⚠️ 問題根源

之前網站顯示舊版本的原因有三個：

1. **瀏覽器快取** - 瀏覽器會快取 JavaScript 和 CSS 檔案
2. **GitHub Pages CDN 快取** - GitHub Pages 使用 CDN，更新需要時間傳播
3. **錯誤的部署流程** - 在錯誤的分支上構建，導致引用舊檔案

---

## ✅ 完整解決方案

### 1. 自動化部署腳本

**使用方法：**

```bash
cd /home/user/webapp
./deploy.sh
```

這個腳本會：
- ✅ 自動切換到 main 分支並更新
- ✅ 完全清理舊的構建檔案和快取
- ✅ 重新安裝依賴並構建
- ✅ 驗證構建結果
- ✅ 部署到 gh-pages 分支
- ✅ 驗證部署的檔案版本正確
- ✅ 自動提交並推送到 GitHub

### 2. Vite 設定優化

檔案：`client/vite.config.ts`

```typescript
build: {
  outDir: 'dist',
  assetsDir: 'assets',
  rollupOptions: {
    output: {
      // 確保每次構建都產生唯一的檔案名稱
      entryFileNames: 'assets/[name]-[hash].js',
      chunkFileNames: 'assets/[name]-[hash].js',
      assetFileNames: 'assets/[name]-[hash].[ext]',
    },
  },
  // 清除舊的輸出
  emptyOutDir: true,
}
```

**作用：**
- 每次構建都會產生新的檔案名稱（如 `index-BjHn9paA.js`）
- 檔案名稱包含內容雜湊值，內容變更則檔案名稱變更
- 徹底避免瀏覽器使用快取的舊檔案

### 3. 手動部署流程（如果不使用腳本）

**步驟 1: 在 main 分支上構建**

```bash
cd /home/user/webapp
git checkout main
git pull origin main

cd client
rm -rf dist node_modules/.vite  # 完全清理
npm install
npm run build
```

**步驟 2: 保存構建到臨時位置**

```bash
cd /home/user/webapp
mkdir -p /tmp/build
cp -r client/dist/* /tmp/build/
```

**步驟 3: 部署到 gh-pages**

```bash
git checkout gh-pages

# 完全清理舊檔案
rm -rf assets/* images/*

# 複製新的構建檔案
cp -r /tmp/build/assets/* assets/
cp -r /tmp/build/images/* images/
cp /tmp/build/index.html .
cp index.html 404.html

# 清理臨時檔案
rm -rf /tmp/build
```

**步驟 4: 驗證**

```bash
# 檢查 index.html 引用的檔案
grep "assets/" index.html

# 檢查資產檔案是否存在
ls -lh assets/
```

**步驟 5: 提交並推送**

```bash
git add -A
git commit -m "deploy: 部署最新版本 - $(date -u '+%Y-%m-%d %H:%M UTC')"
git push origin gh-pages

# 切換回 main 分支
git checkout main
```

---

## 🚫 **絕對不要做的事情**

### ❌ 錯誤 1: 在 gh-pages 分支上構建

```bash
# ❌ 錯誤！
git checkout gh-pages
cd client
npm run build  # gh-pages 上的源碼可能是舊的！
```

**為什麼錯誤：**
- gh-pages 分支的源碼（`src/` 目錄）可能不是最新的
- 會產生舊版本的構建檔案

**✅ 正確做法：**
- 永遠在 main 分支上構建
- 然後將構建結果複製到 gh-pages

### ❌ 錯誤 2: 不清理舊的快取

```bash
# ❌ 錯誤！
cd client
npm run build  # 可能使用快取的舊檔案
```

**✅ 正確做法：**
```bash
cd client
rm -rf dist node_modules/.vite  # 清理快取
npm run build
```

### ❌ 錯誤 3: 不驗證部署結果

```bash
# ❌ 錯誤！
cp client/dist/index.html .
git add -A
git commit -m "deploy"
git push
# 沒有檢查 index.html 是否引用正確的檔案！
```

**✅ 正確做法：**
```bash
cp client/dist/index.html .
grep "assets/" index.html  # 驗證引用
ls -lh assets/             # 確認檔案存在
git add -A
git commit -m "deploy"
git push
```

---

## 🌐 **使用者端快取清除**

即使部署正確，使用者仍然可能看到舊版本，因為：

### 問題 1: GitHub Pages CDN 快取

**時間：** 5-15 分鐘

**解決：** 等待 CDN 更新，無法加速

### 問題 2: 瀏覽器快取

**解決方法：**

#### Chrome / Edge:
1. 按 `Ctrl + Shift + R` (Windows) 或 `Cmd + Shift + R` (Mac)
2. 或右鍵點擊重新整理按鈕 → 選擇「清除快取並強制重新整理」

#### Firefox:
1. 按 `Ctrl + Shift + R` (Windows) 或 `Cmd + Shift + R` (Mac)
2. 或按 `Ctrl + F5`

#### Safari:
1. 按 `Cmd + Option + R`
2. 或開啟「開發」選單 → 選擇「清空快取」

#### 通用方法:
1. **使用無痕/隱私模式** - 不會使用快取
2. **清除瀏覽器資料**：
   - Chrome: 設定 → 隱私權與安全性 → 清除瀏覽資料 → 選擇「快取圖片和檔案」
   - Firefox: 選項 → 隱私權與安全性 → Cookie 與網站資料 → 清除資料
   - Safari: 偏好設定 → 進階 → 清空快取

---

## 📊 **驗證部署成功**

### 檢查清單：

#### 1. 檢查 GitHub 上的檔案

訪問：https://github.com/mrlaifengshui/quantum-fengshui-purifier/tree/gh-pages

確認：
- ✅ `index.html` 更新時間是最新的
- ✅ `assets/` 目錄有正確的檔案
- ✅ 提交訊息顯示最新的部署時間

#### 2. 檢查網站

訪問：https://mrlaifengshui.github.io/quantum-fengshui-purifier/

確認：
- ✅ 所有頁面都能正常載入（不是空白）
- ✅ 技術原理頁面手機版排版正確（圖像-文字-圖像）
- ✅ 所有功能都正常運作

#### 3. 檢查控制台

1. 打開瀏覽器開發者工具（F12）
2. 切換到「Network」（網路）標籤
3. 重新整理頁面
4. 檢查：
   - ✅ JavaScript 檔案名稱是最新的（如 `index-BjHn9paA.js`）
   - ✅ 沒有 404 錯誤
   - ✅ 所有資源都成功載入

---

## 🔄 **未來的工作流程**

### 每次更改代碼後：

1. **在 main 分支上開發和測試**
   ```bash
   git checkout main
   # 修改代碼
   git add .
   git commit -m "feat: 新功能描述"
   git push origin main
   ```

2. **使用自動化部署腳本**
   ```bash
   ./deploy.sh
   ```

3. **等待並驗證**
   - 等待 5-15 分鐘（GitHub Pages CDN 更新）
   - 清除瀏覽器快取
   - 訪問網站並驗證

### 如果遇到問題：

1. **檢查 GitHub Actions**（如果有設定）
2. **檢查 gh-pages 分支的最新提交**
3. **手動驗證 index.html 和資產檔案**
4. **如果需要，重新運行部署腳本**

---

## 📝 **總結：關鍵要點**

### ✅ **必須做：**

1. **永遠在 main 分支上構建**
2. **使用自動化部署腳本**
3. **驗證部署結果**
4. **提醒使用者清除瀏覽器快取**

### ❌ **絕對不要：**

1. **不要在 gh-pages 分支上構建**
2. **不要跳過快取清理步驟**
3. **不要不驗證就推送**

### 🎯 **快取破壞策略的好處：**

- ✅ 每次構建產生唯一的檔案名稱
- ✅ 瀏覽器自動使用新檔案
- ✅ 不需要手動清除 CDN 快取
- ✅ 更新立即生效（除了 GitHub Pages CDN 延遲）

---

## 🚀 **快速參考**

```bash
# 完整部署流程（推薦）
./deploy.sh

# 或手動部署
git checkout main
cd client && rm -rf dist node_modules/.vite && npm install && npm run build && cd ..
mkdir -p /tmp/build && cp -r client/dist/* /tmp/build/
git checkout gh-pages
rm -rf assets/* images/*
cp -r /tmp/build/assets/* assets/ && cp -r /tmp/build/images/* images/
cp /tmp/build/index.html . && cp index.html 404.html
rm -rf /tmp/build
git add -A && git commit -m "deploy: $(date -u '+%Y-%m-%d %H:%M UTC')" && git push origin gh-pages
git checkout main
```

---

**最後更新：** 2025-12-05  
**維護者：** mrlaifengshui  
**專案：** Quantum Feng Shui Air Purification
